import cv2
import base64

def encode_image(image_path):
    with open(image_path, "rb") as img:
        return base64.b64encode(img.read()).decode()

def preprocess_image(image_path):
    return cv2.imread(image_path)
