OPENAI_API_KEY = "your_openai_key"
GEMINI_API_KEY = "your_gemini_key"
