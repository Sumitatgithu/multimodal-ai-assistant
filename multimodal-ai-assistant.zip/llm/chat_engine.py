from langchain.chat_models import ChatOpenAI

def get_response(prompt):
    llm = ChatOpenAI(temperature=0.7)
    return llm.predict(prompt)
